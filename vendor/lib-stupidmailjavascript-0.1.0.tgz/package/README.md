# lib-StupidMailJavaScript

Cliente JavaScript/TypeScript exclusivamente de backend para a API do
[StupidMailCenter](https://mailcenter.stupidll.com). Funciona em Node.js 18 ou
mais recente, possui tipos incluídos e suporta ESM e CommonJS.

## Instalação

```bash
npm install github:Stupid-DLL/lib-StupidMailJavaScript
```

Alternativamente:

```bash
npm install git+https://github.com/Stupid-DLL/lib-StupidMailJavaScript.git
```

## Configuração segura

Defina a credencial somente no ambiente do backend:

```bash
export STUPID_MAIL_CENTER_API_KEY="smc_live_..."
```

No PowerShell:

```powershell
$env:STUPID_MAIL_CENTER_API_KEY = "smc_live_..."
```

`StupidMailCenterService` lê a chave exclusivamente de
`STUPID_MAIL_CENTER_API_KEY`. Não existe opção de construtor para passá-la. A
credencial fica em campo privado e nunca é incluída em erros, logs ou respostas.

Não importe o pacote em componentes client-side, bundles de navegador ou
aplicativos móveis. Use-o em rotas, controllers, workers ou serviços do backend.

## Criar template com variáveis

```js
import { StupidMailCenterService, Template } from "lib-stupidmailjavascript";

const customer = Template.variable("CUSTOMER");
const order = Template.variable("ORDER");
const template = new Template({
  name: "pedido-confirmado",
  subject: `Pedido ${order} confirmado`,
  html: `<h1>Olá, ${customer}!</h1><p>O pedido ${order} foi confirmado.</p>`,
  text: `Olá, ${customer}! O pedido ${order} foi confirmado.`,
});

const mail = new StupidMailCenterService();
const created = await mail.createTemplate(template);
console.log(created.id);
```

`Template.variable()` produz placeholders validados como `{{{CUSTOMER}}}`. Para
carregar arquivos mantidos no backend:

```js
const template = await Template.fromFiles({
  name: "boas-vindas",
  subject: `Bem-vindo, ${Template.variable("NAME")}`,
  htmlPath: "templates/boas-vindas.html",
  textPath: "templates/boas-vindas.txt",
});
```

## Enviar usando o template

```js
const mail = new StupidMailCenterService({ timeoutMs: 10_000, maxRetries: 3 });
const result = await mail.sendTemplate({
  from: "noreply@stupidll.com",
  to: "cliente@example.com",
  templateId: "template-id-retornado-na-criacao",
  templateVariables: { CUSTOMER: "Ada", ORDER: 1042 },
  idempotencyKey: "pedido/1042/confirmacao",
});
```

Sem `idempotencyKey`, a biblioteca gera uma chave por chamada e a reutiliza em
todos os retries. Para deduplicação entre processos ou reinícios, forneça uma
chave estável ligada à operação de negócio.

## Enviar sem template

```js
const result = await mail.sendEmail({
  from: "noreply@dominio-verificado.com",
  to: ["primeiro@example.com", "segundo@example.com"],
  cc: "auditoria@example.com",
  replyTo: "suporte@example.com",
  subject: "Processamento concluído",
  html: "<p>Seu arquivo está pronto.</p>",
  text: "Seu arquivo está pronto.",
  idempotencyKey: "processamento/8d60fc",
});
```

O remetente deve ser `noreply@stupidll.com` ou `noreply` em outro domínio
autorizado e verificado.

## CommonJS

```js
const { StupidMailCenterService, Template } = require("lib-stupidmailjavascript");
```

## Erros e retries

- timeout e falhas de rede: retry exponencial limitado;
- `401`: `AuthenticationError`;
- `403`: `ForbiddenError`;
- `429`: respeita `Retry-After` e lança `RateLimitError` ao esgotar as tentativas;
- `5xx`: retry exponencial com jitter;
- outras falhas: `StupidMailCenterError` ou `TransportError`.

Por padrão, o timeout é de 10 segundos e são permitidos até três retries.

| Operação | Escopo |
| --- | --- |
| `sendEmail` / `sendTemplate` | `email:send` |
| `listTemplates` | `template:read` |
| `createTemplate` | `template:write` |

## Desenvolvimento

```bash
npm install
npm run check
npm test
npm run build
npm pack --dry-run
```

